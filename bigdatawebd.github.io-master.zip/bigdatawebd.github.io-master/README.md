# bigdatawebd
Website for Short term course in december iitp on big data
